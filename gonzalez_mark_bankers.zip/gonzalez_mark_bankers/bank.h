//
//  bank.h
//
//

#ifndef __BANK_H__
#define __BANK_H__

#include "customer.h"


class Bank {
public:
  Bank() = default;
  Bank(const ext_vector<int>& available) : avail(available), customers() { }
  
  ext_vector<int> get_avail() const { return avail; }
  bool is_avail(const ext_vector<int>& req) const { return req <= avail; }
  
  bool is_safe(int id, const ext_vector<int>& req) { 
    if (customers.size() == 1) { return true; }

    bool safe = false;
    Customer* tmp = customers[id];

    if (!withdraw_resources(req)) { return false; }
    tmp->alloc_req(req);

    //pthread_mutex_lock(&mutex_);
    for (Customer* c : customers) {
      if (avail >= c->needs() && c->get_id() != tmp->get_id()) { safe = true; break; }
    }
    //pthread_mutex_unlock(&mutex_);

    tmp->dealloc_req(req);
    deposit_resources(req);

    return safe; 
  }

  bool req_approved(int id, const ext_vector<int>& req) {
    if (req > avail) { return false; }

    const Customer* c = customers[id];
    if (c->needs_exceeded(req)) { return false; }

    return is_safe(id, req);
  }
  
  void add_customer(Customer* c) {
    //std::cout << avail << " : " << c->allocated() << " = " << (avail - c->allocated()) << "\n";
    //if (avail < c->allocated()) {std::cout << "sdjbaspdjnqosjndpqksnmdpokan\n";}

    if (!withdraw_resources(c->allocated())) {
      std::cout << "could not add customer P#" << c->get_id() << "\n" ;
      return;
    }
    std::cout << "adding customer P#" << c->get_id() << " with [" << c->allocated() << "] resources" << "\n" ;
    std::cout << "bank has [" << avail << " ] left\n";
    customers.push_back(c);
  }
  
  bool withdraw_resources(const ext_vector<int>& req) {
    //pthread_mutex_lock(&mutex_);
    if (!is_avail(req)) {
      std::cerr << "WARNING: req: " << req << " is not available for withdrawing\n";
      //pthread_mutex_unlock(&mutex_);
      return false;
    }
    avail -= req;
    //pthread_mutex_unlock(&mutex_);
    return true;
  }
  void deposit_resources(const ext_vector<int>& req) { 
      //pthread_mutex_lock(&mutex_);
      avail += req; 
      //pthread_mutex_unlock(&mutex_);
    }


  ext_vector<Customer*> get_customers() const { return customers; }
  
  void show() const {
    //pthread_mutex_lock(&mutex_);
    std::cout << "avail: [" << avail << "]\n";
    //pthread_mutex_unlock(&mutex_);
    
    for (Customer* c : customers) {
      c->show();
    }
    std::cout << "\n";
  }
  
  friend std::ostream& operator<<(std::ostream& os, const Bank& be) {
    be.show();
    return os;
  }

private:
  ext_vector<int> avail;
  ext_vector<Customer*> customers;
};

#endif /* Bank_h */
